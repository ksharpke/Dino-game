
const canvas = document.getElementById('gameCanvas');
const context = canvas.getContext('2d');
canvas.width = 800;
canvas.height = 200;

// Dino object
let dino = {
  x: 50,
  y: 150,
  width: 50,
  height: 50,
  jumping: false,
  velocityY: 0,
  gravity: 0.8
};

function drawDino() {
  context.fillStyle = 'green';
  context.fillRect(dino.x, dino.y, dino.width, dino.height);
  // Add signature behind dino
  context.font = '20px Arial';
  context.fillStyle = 'rgba(0, 0, 0, 0.2)';
  context.fillText('Kemal Emre Özdemir', 600, 180);
}

function update() {
  if (dino.jumping) {
    dino.velocityY -= dino.gravity;
    dino.y -= dino.velocityY;

    if (dino.y >= 150) {
      dino.jumping = false;
      dino.y = 150;
      dino.velocityY = 0;
    }
  }
}

function jump() {
  if (!dino.jumping) {
    dino.jumping = true;
    dino.velocityY = 15;
  }
}

canvas.addEventListener('click', jump);

function gameLoop() {
  context.clearRect(0, 0, canvas.width, canvas.height);
  drawDino();
  update();
  requestAnimationFrame(gameLoop);
}

gameLoop();
